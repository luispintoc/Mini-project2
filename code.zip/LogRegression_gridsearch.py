import os, re, json, math
from random import shuffle
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split, GridSearchCV
from nltk.corpus import stopwords, movie_reviews
from sklearn.svm import LinearSVC, SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.preprocessing import Normalizer, FunctionTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_classif, chi2
import warnings
import nltk
#from pattern.en import sentiment    #pip install pattern
# nltk.download('movie_reviews')
warnings.filterwarnings("ignore",category = FutureWarning)

#		*****Initialization*****

train_pos_path = 'train//pos'
train_neg_path = 'train//neg'
target = [] 
reviews = []
positive_words = []
negative_words = []
bing_liu_list = []


#		********Read data*********

for file in os.listdir(train_pos_path):
    with open(os.path.join(train_pos_path,file),"r",encoding="utf8") as f:
        reviews.append(f.read())

for file in os.listdir(train_neg_path):
    with open(os.path.join(train_neg_path,file),"r",encoding="utf8") as f:
        reviews.append(f.read())

target = [1 if i<12500 else 0 for i in range(25000)]

train_data = list(zip(target,reviews))
shuffle(train_data)

target = [] 
reviews = []

i = 0
while i < 25000:
    target.append(train_data[i][0])
    reviews.append(train_data[i][1])
    i += 1

with open('positive-words.txt') as f:
    positive_words = f.read().splitlines()
with open('negative-words.txt') as f:
    negative_words = f.read().splitlines()

bing_liu_list = list(zip(positive_words,negative_words))
# words_for_movies = list(movie_reviews.words())
# vocab = list(set(bing_liu_list + words_for_movies))


#		********Preprocessing********

delete = re.compile("(\.)|(\;)|(\:)|(\!)|(\')|(\?)|(\,)|(\")|(\()|(\))|(\[)|(\])")
replace_with_space = re.compile("(<br\s*/><br\s*/>)|(\-)|(\/)")

def compile(reviews):
	reviews = [delete.sub("",line.lower()) for line in reviews]
	reviews = [replace_with_space.sub(" ",line) for line in reviews]
	return reviews

# def get_stemmed_text(corpus,name):
#     if name == 'Porter':
#         from nltk.stem.porter import PorterStemmer
#         stemmer = PorterStemmer()
#     else:
#         from nltk.stem.snowball import SnowballStemmer
#         stemmer = SnowballStemmer("english")
#     return [' '.join([stemmer.stem(word) for word in review.split()]) for review in corpus]

# def get_lemmatized_text(corpus):
#     import nltk
#     nltk.download('wordnet')
#     from nltk.stem import WordNetLemmatizer
#     lemmatizer = WordNetLemmatizer()
#     return [' '.join([lemmatizer.lemmatize(word) for word in review.split()]) for review in corpus] 

# def get_sentiment(x):
#     return np.array([sentiment(t)[0] for t in x]).reshape(-1, 1)

# def get_sentiment2(x):
#     return np.array([sentiment(t)[1] for t in x]).reshape(-1, 1)

# def get_text_length(x):
#     return np.array([len(t) for t in x]).reshape(-1, 1)

# def length_times_sentiment(x):
#     a = np.array([sentiment(t)[0] for t in x]).reshape(-1, 1)
#     b = np.array([math.sqrt(len(t)) for t in x]).reshape(-1, 1)
#     return [a*b for a,b in zip(a,b)]

# def length_times_sentiment2(x):
#     a = np.array([sentiment(t)[1] for t in x]).reshape(-1, 1)
#     b = np.array([math.sqrt(len(t)) for t in x]).reshape(-1, 1)
#     return [a*b for a,b in zip(a,b)]


#		*******Feature pipeline******

pipeline = Pipeline([
    ('features_union', FeatureUnion([
                ('ngrams_feature', Pipeline([('ngrams_vect', TfidfVectorizer(binary = True, ngram_range=(1,2)))
            # ])),
            #     ('words_feature', Pipeline([('words_vect', CountVectorizer(min_df = 2, binary = True, vocabulary = bing_liu_list))
            # ])),
            #     ('length',Pipeline([('count', FunctionTransformer(get_text_length, validate = False))
            # ])),
            #     ('sent',Pipeline([('sentiment', FunctionTransformer(get_sentiment, validate = False))
            # ])),
            #     ('sent2',Pipeline([('sentiment2', FunctionTransformer(get_sentiment2, validate = False))
            # ])),
            #     ('other',Pipeline([('other', FunctionTransformer(length_times_sentiment, validate = False))
            # ])),
            #     ('other2',Pipeline([('other2', FunctionTransformer(length_times_sentiment2, validate = False))
    ]))])),
    ('normalization', Normalizer(copy=False)),
    ('reduce_dim', None),
    ('classifier', LogisticRegression(penalty = 'l2', max_iter = 4000, solver = 'lbfgs', C = 100))])


#       *********Applying preprocessing*******

reviews = compile(reviews)


#		*********Grid Search*******


parameters_grid = {	#'classifier__C': (10,200,1000,7000),
                    #'classifier__max_iter': (100,500,1000),
                    'reduce_dim':[SelectKBest(chi2)],
                    'reduce_dim__k':(70000,65000,58000)} #70000 -> 90.59 accuract=y


		# *********Validation Pipeline*******

print('Running gridseach on Logistic Regression')


grid_search = GridSearchCV(pipeline, parameters_grid, cv=4, n_jobs=-1, scoring='accuracy')
grid_search.fit(reviews,target)
cvres = grid_search.cv_results_
for accuracy, params in zip(cvres['mean_test_score'],cvres['params']):
	print('Mean accuracy: ', accuracy,'  using: ',params)