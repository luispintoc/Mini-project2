import os, re, json, math
from random import shuffle
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split, GridSearchCV
from nltk.corpus import stopwords, movie_reviews
from sklearn.svm import LinearSVC, SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.preprocessing import Normalizer, FunctionTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_classif, chi2
from sklearn.ensemble import VotingClassifier
import warnings
import nltk
import natsort, csv
warnings.filterwarnings("ignore",category = FutureWarning)


#		*****Initialization*****

filter_words = []
target = []
reviews_train = []  #first 12500 are positive reviews, the rest are negative
reviews_test = []
train_pos_path = 'train//pos'
train_neg_path = 'train//neg'
test_path = 'test'
y_test = []
stopwords = []


#		******Read data******

for file in os.listdir(train_pos_path):
	with open(os.path.join(train_pos_path,file),"r",encoding="utf8") as f:
		reviews_train.append(f.read())

for file in os.listdir(train_neg_path):
	with open(os.path.join(train_neg_path,file),"r",encoding="utf8") as f:
		reviews_train.append(f.read())

for file in natsort.natsorted(os.listdir(test_path),reverse=False):
	with open(os.path.join(test_path,file),"r",encoding="utf8") as f:
		reviews_test.append(f.read())

with open('positive-words.txt', 'rb') as f:
    positive_words = f.read().splitlines()
with open('negative-words.txt', 'rb') as f:
    negative_words = f.read().splitlines()


bing_liu_list = list(zip(positive_words,negative_words))

y_train = [1 if i<12500 else 0 for i in range(25000)]


#		********Preprocessing********

delete = re.compile("(\.)|(\;)|(\:)|(\!)|(\')|(\?)|(\,)|(\")|(\()|(\))|(\[)|(\])")
replace_with_space = re.compile("(<br\s*/><br\s*/>)|(\-)|(\/)")

def compile(reviews):
	reviews = [delete.sub("",line.lower()) for line in reviews]
	reviews = [replace_with_space.sub(" ",line) for line in reviews]
	return reviews

def normalization(train,test):
	norm = Normalizer().fit(train)
	train = norm.transform(train)
	test = norm.transform(test)
	return train, test


#       *********Applying preprocessing*******
x_train = compile(reviews_train)
x_test = compile(reviews_test)

#		*********Classifiers*******
clf1 = LinearSVC(penalty = 'l2', max_iter = 4000, C=100)
clf2 = LogisticRegression(solver= 'lbfgs', penalty='l2', max_iter = 1000, C=100)
# eclf = VotingClassifier(estimators=[('svc',clf1),('lr',clf2)],weights = [2,1])

clf3 = RandomForestClassifier(criterion = 'gini', n_estimators=150,min_samples_split = 2)
eclf = VotingClassifier(estimators=[('svc',clf1),('lr',clf2),('rf',clf3)])

pipeline = Pipeline([('select',SelectKBest(chi2, k = 530000 )),('clf',eclf)])


#		*******Features Pipeline******
pipeline = Pipeline([
    ('features_union', FeatureUnion([
                ('ngrams_feature', Pipeline([('ngrams_vect', TfidfVectorizer(binary = True, ngram_range=(1,3)))
            ])),
                ('words_feature', Pipeline([('words_vect', CountVectorizer(vocabulary = bing_liu_list, binary = True, min_df = 2))
    ]))])),
    ('normalization', Normalizer(copy=False)),
    ('classifier', eclf)])


#		*******Fit and Transform******

print('This script outputs a CSV for the uncomment ensemble')

pipeline.fit(x_train,y_train)
y_test = pipeline.predict(x_test)
print(y_test)

id = list(range(25000))
ss = list(zip(id,y_test))

with open('submission_kaggle.csv', 'w', newline = '') as f:
     writer = csv.writer(f, delimiter=',')
     writer.writerows(ss)
